package rsa;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

public class RSA {
    private BigInteger n;
    private BigInteger phi;
    private BigInteger e;

    // Constructor that initializes the modulus and public exponent
    public RSA(BigInteger p,BigInteger q, BigInteger e) {
        this.phi = p.subtract(BigInteger.valueOf(1)).multiply(q.subtract(BigInteger.valueOf(1)));
        this.n = p.multiply(q);
//        System.out.println("n = "+ n + " phi = "+this.phi);
        this.e = e;
    }

    public BigInteger encrypt(BigInteger message){
//        System.out.println("e = " + this.e + " n = "+this.n+" | m = " + message );
        BigInteger t = message.modPow(this.e,this.n);
        return t;
    }
    public BigInteger decrypt(BigInteger cipher){
//        System.out.println("phi = (p-1)*(q-1) = " + this.phi );
//        BigInteger d =  new BigInteger(String.valueOf(modI(this.e.intValue(),this.phi.intValue()))) ; //Math.pow(e, -1) % phi;
        BigInteger d =  new BigInteger(String.valueOf(this.e.modInverse(this.phi))); //Math.pow(e, -1) % phi;
//        System.out.println("d = Math.pow(e, -1) % phi = " + d );
        BigInteger m = cipher.modPow(d,this.n);
//        System.out.println("m = Math.pow(cipher, d) % n = " + m );
        return m;
    }



    public static int modI(int m , int n){
        int result =-1;
        int mod = -1;
        int temp_m = m;
        int temp_n = n;
        List<Integer> second_column = new ArrayList<>();
        int last_mod = 0;
        while(mod != 0){
            mod = n % m;
            result = (n-mod) / m;
            n = m;
            m = mod;
            second_column.add(result);
            if(mod > 0){
                last_mod = mod;
            }
        }
        m = temp_m;
        n = temp_n;
        List<Integer> third_column = new ArrayList<>();
        third_column.add(0);
        third_column.add(last_mod);
        for(int i = second_column.size() -2 ; i > -1 ; i--){
            int temp = second_column.get(i) * third_column.get(third_column.size() - 1) +third_column.get(third_column.size() - 2) ;
            third_column.add(temp);
        }
        int x = third_column.get(third_column.size() - 1);
        int y = third_column.get(third_column.size() - 2);
        int ny  = n * y;
        int xm  = x * m;
        if((ny - xm) == 1){
            result =  (((-x % n) + n) % n);
        }else if((-ny + xm) == 1){
            result = x;
        }
        return result;
    }
    // Function to return gcd of a and b
    static BigInteger gcd(BigInteger a, BigInteger b)
    {
        if (a.compareTo(BigInteger.valueOf(0)) == 0)
            return b;
        return gcd(b.mod(a), a);
    }
    public static BigInteger chooseE(BigInteger p , BigInteger q){
        BigInteger phi = p.subtract(BigInteger.valueOf(1)).multiply(q.subtract(BigInteger.valueOf(1)));
        BigInteger e = new BigInteger("0");
        while(e.compareTo(BigInteger.valueOf(1)) != 0 || e.compareTo(BigInteger.valueOf(1)) <= 0 || e.compareTo(phi) >= 0){
            e.add(new BigInteger("1")) ;
        }
        return e;
    }
}
